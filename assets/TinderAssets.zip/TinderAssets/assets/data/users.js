export default [
  {
    id: '1',
    name: 'Vadim Savin',
    image:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/vadim1.JPG',
    bio: 'I will be the semicolons to your code',
  },
  {
    id: '2',
    name: 'Elon Musk',
    image:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/elon.png',
    bio: 'A dude with a rocket is looking for a gal with fuel',
  },
  {
    id: '3',
    name: 'Zuck',
    image:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/zuck.jpeg',
    bio: 'No need to send me your nudes, I already saw them',
  },
  {
    id: '4',
    name: 'Jeffrey Bezos',
    image:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/jeff.jpeg',
    bio: 'CEO, entrepreneur born in 1964, Jeffrey, Jeffrey Bezos',
  },
  {
    id: '5',
    name: 'Vadim Savin',
    image:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/vadim1.JPG',
    bio: 'Hola',
  },
];
